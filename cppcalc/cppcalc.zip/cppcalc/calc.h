#ifndef calc_h
#define calc_h

extern int memory;

#endif
